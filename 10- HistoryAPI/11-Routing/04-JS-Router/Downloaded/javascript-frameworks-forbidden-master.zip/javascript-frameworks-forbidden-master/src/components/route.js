

// take a list of routes and switch them based on the URL

/**
 * @param {Array} routes
 * @param routes
 */
export default   (hostComponent) =>{
    debugger
   // some route code
    const initialContent = hostComponent.innerHTML

}
const route = (hostComponent,path, handler) => {

}
